<!DOCTYPE html>
<html>
<head>
	<title>Welcome to Multibank </title>
	<link rel="stylesheet" type="text/css" href="connection/bootstrap5.css">
	<style type="text/css">
		.center{
			position: fixed; /* or absolute */
		  top: 50%;
		  left: 50%;
		  /* bring your own prefixes */
		  transform: translate(-50%, -50%);

		}
	</style>
</head>
<body class="bg-dark">

	<div class="bg-primary center p-3" style="max-width: 600px; margin: 0 auto; ">
		<div>
			<div class="h3 text-center text-light">
				Welcome multiBank User
			</div>
			<div class="m-3">
				<a class="btn btn-success w-100 mb-2"  href="user/home/">General User</a>
				<a class="btn btn-info w-100 mb-2" href="agent/">Agent</a>
				<a class="btn btn-danger w-100 mb-2"  href="control/">Control Panel</a>
				
			</div>
			

		</div>
	</div>
	<?php //header("location:user/home/"); ?>
</body>
</html>














<?php 
	
	$host= 'localhost';
	$username='root';
	$password='';
	$dbname='multi';
	$con=new mysqli("localhost","root","");
	$con->query("CREATE DATABASE IF NOT EXISTS `multi`");
	$con=mysqli_connect($host, $username, $password, $dbname);
	$create_user_info_table=mysqli_query($con,"CREATE TABLE IF NOT EXISTS `multi_user`(id int(11) NOT NULL AUTO_INCREMENT, name varchar(100), nid int(20), father varchar(100), mother varchar(100), phone varchar(15), roll int(12), registration int(20), password varchar(2000), PRIMARY key(id))");

	$create_table_agent=$con->query("CREATE TABLE IF NOT EXISTS `multi_agent`(id int(11) NOT NULL AUTO_INCREMENT, name varchar(100), nid int(20), father varchar(100), mother varchar(100), phone varchar(15), roll int(12), registration int(20), password varchar(2000), PRIMARY key(id))");

	$create_banar_table=$con->query("CREATE TABLE IF NOT EXISTS `banar`(id int not null AUTO_INCREMENT, name_img varchar(200), date  datetime NOT NULL DEFAULT current_timestamp(), PRIMARY key(id))");

	$create_massage=$con->query("CREATE TABLE IF NOT EXISTS `massage`(id int not null AUTO_INCREMENT, name varchar(200), img varchar(200), content varchar(1000), date  datetime NOT NULL DEFAULT current_timestamp(), PRIMARY key(id))");
	
	$create_slider=$con->query("CREATE TABLE IF NOT EXISTS `slider`(id int not null AUTO_INCREMENT, name varchar(200), img varchar(200), content varchar(1000), date  datetime NOT NULL DEFAULT current_timestamp(), PRIMARY key(id))");
	$create_ad=$con->query("CREATE TABLE IF NOT EXISTS ads(id int not null AUTO_INCREMENT, name varchar(150), img varchar(1000), link varchar(1500), date varchar(50), PRIMARY key(id))");


