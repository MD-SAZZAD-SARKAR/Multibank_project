<!DOCTYPE html>
<html>
<head>
	<title>This is redirecting homw page</title>
</head>
<body>
	<?php header('location:home/'); ?>
</body>
</html>