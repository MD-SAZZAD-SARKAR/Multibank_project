<!DOCTYPE html>
<html>
<head>
	 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank user interface</title>

	<style type="text/css">
		#relative{
			position: relative;
		}
		#menu_full{
			background: blue;
			position: absolute;
			top: 0;
			right: 0;
			width: 0;
			border-radius: 5px;
			width: 70%;
			display: none;
			padding: 15px;
			

		}
		#menu_full hr{
			color: white;
		}
		#menu_full p span{
			float: right;
		}
		#menu_full p #close{
			font-size: 30px;
			color: red;
			font-weight: bold;
			margin-top: -10px;
		}
		
		#satar{
			margin: 0;
			padding: 0;
		}
		#back{
			margin: 0;
			padding: 0;
		}
		#back div:hover{
			background: #eee;
		}
		#back div a{
			text-decoration: none;
			font-size: 15px;
		}
		#back div a:hover{
			font-size: 15px;
			background: #eee;
			cursor: pointer;
		}
		#close:hover{
			cursor: pointer;
		}
		img:hover{
			cursor:pointer;
		}
		.slider_info{
			display: none;
			width: 100%;
		}
	</style>
	<?php session_start();
	if (!isset($_SESSION['enter'])) {
		echo "<script>window.location.href='../home/'</script>";
	}else if (!isset($_SESSION['phone_agent'])) {
		echo "<script>window.location.href='../check_account/'</script>";
	} else if (!isset($_SESSION['login_agent'])) {
		echo "<script>window.location.href='../login/'</script>";
	}else if (!isset($_SESSION['active'])) {
		echo "<script>window.location.href='../login/'</script>";
	}
	
		require_once("../../connection/dbcon.php");
		
	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div id="relative" class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to left, #2c2ce8, #e82c6e, #2ce8b9, #e4e82c, red); ">
			<div class="container">
			  <div class="row">
			    <div class="col-6">
			     <img style="width: 100px;" src="/Image/multi.png" title="logo">
			    </div>
			   
			    <div  class="col-6 mb-2 text-end text-light mt-3">
			     <img id="menu" style="width: 20px;" src="/Image/menu-circles.png">
			     <?php require_once('../side/index.php'); ?>
			    </div>
			    
			  </div>
			  <div class="row bg-light rounded">
			  	<div class="text-center" id="satar">
			  		<div>
			  			<button id="money" disabled class="disabled btn btn-secondary w-100">
			  				<?php 
			  					$phone=$_SESSION['phone_agent'];
			  					$debit=0;
			  					$creadit=0;
			  					$slect_money=mysqli_query($con,"SELECT * FROM `$phone`");
			  					while ($row=mysqli_fetch_assoc($slect_money)) {
			  						$debit+=$row['debit'];
			  						$creadit+=$row['creadit'];
			  					}

			  					$money=($creadit/1)-($debit/1);
			  					$_SESSION['money']=$money;
			  					echo $money;
			  				 ?>
			  				<span>৳</span></button>
			  			<button id="money_btn" class="btn btn-secondary w-100">Show money</button>

			  		</div>
			  	</div>
				  	<div class="container-fulid row m-0 p-0 col-12">
					  
					  <div id="back" class="col-4">
					  	<div class="m-1 p-2 border ">
					  		<a href="../cashin/">
					  			<img class="w-100" src="/image/money.png">
					  			<p class="text-center">Cash In</p>
					  		</a>
					  	</div>
					  </div>
					  <div id="back" class="col-4">
					  	<div class="border m-1 p-2 " >
					  		<a href="#">
					  			<img class="w-100" src="/image/payment-method.png">
					  			<p class="text-center"> comming soon... </p>
					  		</a>
					  	</div>
					  </div>
					   <div id="back" class="col-4">
					  	<div class="border m-1 p-2 " >
					  		<a href="#">
					  			<img class="w-100" src="/image/mobile-app.png">
					  			<p class="text-center">comming soon...</p>
					  		</a>
					  	</div>
					  </div>
					  
					   
					  
					   <div id="back" class="col-12">
					  	<div class="border m-1 p-2 " >
					  		<?php 
					  			$select_slider=mysqli_query($con,"SELECT * FROM `slider`");
					  			while($row_slider=mysqli_fetch_assoc($select_slider)){
					  		 ?>
					  			<img class="slider_info" style="display: none;" class="w-100" src="/image/<?= $row_slider['img']; ?>">
					  		<?php } ?>	

					  	</div>
					  </div>
					  <div class="row">
					  		<?php 
					  			$select_ads=$con->query("SELECT * FROM `ads`");
					  			while($row_ads=$select_ads->fetch_assoc()){
					  		 ?>
					  		
					  		<div class="col-4 p-0 m-0">
					  			
					  			<a class="w-100 text-center d-block p-2" style=" text-decoration: none; text-transform: capitalize;"  href="<?php echo($row_ads['link']); ?>"><img src="/Image/<?php echo($row_ads['img']); ?>" class="w-100" style="border-radius: 5%;"><?php echo $row_ads['name']; ?></a>

					  		</div>
					  		

					  		<?php } ?>
					  	</div>


				  	</div>
				</div>

				<div>
					<div class="container-fulid">
						<div class="row">
							<hr class="m-0 p-0">
							<button id="home" class="btn col-6 rounded" style="background: linear-gradient(to left, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/home.png"> Home</button>

							<button id="inbox" class="btn col-6 rounded" style="background: linear-gradient(to right, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/email.png"> Inbox</button>
						</div>
					</div>
				</div>
			</div>
				
		</div>
	</div>
	<script type="text/javascript">
		var home=document.querySelector('#home');
		var inbox=document.querySelector('#inbox');
		home.style.background='white';
		inbox.style.background='linear-gradient(to right, #03C0CE, #565DDF)';
		inbox.onclick=function(){
			window.location.href='../inbox/';
		}


		var menu=document.querySelector('#menu');
		var menu_full=document.querySelector('#menu_full');
		var close=document.querySelector('#close');
		close.style.display='none';
		menu.onclick=function () {
			menu_full.style.display='block';
			close.style.display='block';
		}
		close.onclick=function () {
			menu_full.style.display='none';
			this.style.display='none';
		}


		var money=document.querySelector('#money');
		var money_btn=document.querySelector('#money_btn');
		money.style.display='none';

		money_btn.onclick=function(){
			money.style.display='block';
			money_btn.style.display='none';
			setTimeout(function(){
				money.style.display='none';
				money_btn.style.display='block';
			},5000);
		}


		 slider_info=document.querySelectorAll('.slider_info');
		 var l=0;
		 setInterval(function(){
		 	for (var i = slider_info.length - 1; i >= 0; i--) {
		 		slider_info[i].style.display='none';
		 	}
		 	slider_info[l].style.maxHeight='100px';
			 slider_info[l].style.display='block';
			 if (l==slider_info.length-1) {
			 	l=0;
			 }else{
			 	l++;
			 }

		},2000);
	</script>
</body>
</html>