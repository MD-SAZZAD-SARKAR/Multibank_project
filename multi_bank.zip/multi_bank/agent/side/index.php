							<div id="menu_full">
			     	<?php 
						$phone_user=$_SESSION['phone_agent'];
						$select_user_multi=$con->query("SELECT * FROM `multi_agent` WHERE `phone`='$phone_user'");
						$row_user_multi=$select_user_multi->fetch_assoc();

					?>
			     	<p style="text-align: left;">Welcome to: <?php echo $row_user_multi['name']; ?> (<?php echo $row_user_multi['phone']; ?>)<span class="text-right" id="close">x</span></p>
			     	<hr>
			     	<div style="text-align: left;"></div>
			     	<div style="text-align: left;"><a class="btn btn-primary w-100" href="/Image/user_manual.pdf" download="">user Menual</a></div>
			     	
			     	<div style="text-align: left;"><a class="btn btn-primary w-100" href="../logout">Logout</a></div>
			     	


			     	<hr>
			     	<div style="text-align: center;">Thank you</div>

			     	
			     	

			     </div>