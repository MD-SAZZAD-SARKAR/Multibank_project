
<h3 class="text-center">Tranjectio History</h3>

<table class="table">
	<tr>
		<th>T Name</th>
		<th>Amount</th>
		<th>T id</th>
	</tr>
	<?php 
	$phone=$_SESSION['phone_agent'];
	$count_row=0;
	$row=mysqli_query($con, "SELECT * FROM `$phone` ORDER BY `id` DESC");
	while ($roww=mysqli_fetch_assoc($row)) {
		$count_row+=1;
		if ($count_row==21) {
			break;
		}
	
 ?>
	<tr>
		<td>
			<?php
	  if($roww['btob']!==''){
	  	echo 'B2B '.$roww['btob'];
	} 

	?>
	<?php
	  if($roww['dilar']!==''){
	  	echo 'Dilar '.$roww['dilar'];
	} 

	?>
	<?php
	  if($roww['cash_out']!==''){
	  	echo 'Cash Out '.$roww['cash_out'];
	} 

	?>
	<?php
	  if($roww['cashin']!==''){
	  	echo 'Cash In '.$roww['cashin'];
	} 

	?>
		</td>
		<td>
			<?php
		  if($roww['debit']!=='' AND $roww['debit']!=='0'){
		  	echo'-'. $roww['debit'];
		} 

		?>

	<?php
		  if($roww['creadit']!==''){
		  	echo '+'.$roww['creadit'];
		} 

	?>
		</td>
		<td>
			<?php
		  if($roww['tranjection_id']!=='NAN'){
		  	echo $roww['tranjection_id'];
		} 

	?>
		</td>
	</tr>


<?php } ?>
</table>