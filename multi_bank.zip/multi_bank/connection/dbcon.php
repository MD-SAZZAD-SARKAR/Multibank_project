
<link rel="icon" type="image/x-icon" href="/image/fav.ico">
<?php
	$host= 'localhost';
	$username='root';
	$password='';
	$dbname='multi';
	$con=mysqli_connect($host, $username, $password, $dbname);
	
	// $indicate=$_SERVER['REQUEST_URI'];;
	// $indicate=explode('/', $indicate);
	// $indicate=$indicate[0];
	// $indicate1=$indicate[1];
	// if ($indicate1='user_interface') {
		
	// }
?>




