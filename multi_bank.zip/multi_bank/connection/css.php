<link rel="stylesheet" type="text/css" href="/connection/bootstrap5.css" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="/connection/filter_progress.css" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="/connection/nivo-slider.css" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+Bengali:wght@500&display=swap" rel="stylesheet"crossorigin="anonymous"> 
<style type="text/css">
	.center{
			position: fixed; /* or absolute */
		  top: 50%;
		  left: 50%;
		  /* bring your own prefixes */
		  transform: translate(-50%, -50%);

		}
</style>