
 <!DOCTYPE html>
 <html>
 <head>
 	<title>404 err</title>
 </head>
 <body>
 	<?php require_once "../connection/css.php"; ?>
 	<?php require_once "../err/index.php"; ?>

 	<div class="d-grid  gap-2 col-6 mx-auto">
 		<a class="btn btn-primary" href="/">Go to home page</a>
 	</div>
 </body>
 </html>