<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank home page</title>
	<?php session_start();
		if (isset($_SESSION['login'])) {
			header('location:../login/');

		}
		if (!$_SESSION['enter']) {
			echo "<script> window.location.href='../home/'</script>";
		}

		require_once("../../connection/dbcon.php");
		if (isset($_POST['submit'])) {
			$number=$_POST['number'];
			$_SESSION['phone']=$number;
			$select_user_account=mysqli_query($con, "SELECT * FROM `multi_user` WHERE `phone`= $number");
			$num_rows=mysqli_num_rows($select_user_account);
			if ($num_rows<1) {
				header('location:../registration/');
			}else{
				echo "<script> window.location.href='../login/'</script>";
				}
		}

	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div class="container-fulid center" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<h1 class="text-center"><img src="/Image/multi.png"></h1>
				<div>
					
				</div>
				<div>
					<br>
				</div>
				<form method="post" action="">
					<div class="row g-3 align-items-center">
					  <div class="col-auto">
					    <label for="inputPassword6" class="col-form-label">Phone +88</label>
					  </div>
					  <div class="col-auto mb-3">
					    <input type="phone" required="" placeholder="013********" pattern= "[0-9]{11}" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline" name="number">
					  </div>
					</div>
					<input class="btn btn-primary" style="max-width: 200px; display: block; margin: 0 auto;" type="submit" name="submit" value="Login/ Registration">
				</form>
				<p class="text-center">You can create account by nid or student id card.</p>
			</div>
		</div>
	</div>
</body>
</html>