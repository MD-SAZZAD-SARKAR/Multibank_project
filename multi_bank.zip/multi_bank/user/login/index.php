<!DOCTYPE html>
<html>
<head>
	  <meta charset="UTF-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	  <title>Multi bank Registration page</title>

	<?php session_start();
		if (!isset($_SESSION['enter'])) {
			echo "<script>window.location.href='../home/'</script>";
		}else if(!isset($_SESSION['phone'])) {
			echo "<script>window.location.href='../check_account/'</script>";
		}
		require_once("../../connection/dbcon.php");
		if(isset($_POST['submit'])){
			$phone=$_SESSION['phone'];
			$password=$_POST['password'];
			
			if (empty($password)) {
				$select_user=mysqli_query($con,"SELECT * FROM `multi_user` WHERE `phone`='$phone' AND `password`='$password'");
				if(mysqli_num_rows($select_user)==1){
					$_SESSION['reg_pass_set']=$phone;
					header('location:../password_set/');
				}else{
					$err="You try empty password";
				}
			}else{
				$password=md5($password);
				$select_user=mysqli_query($con,"SELECT * FROM `multi_user` WHERE `phone`='$phone' AND `password`='$password'");
				if(mysqli_num_rows($select_user)==1){
					$_SESSION['login']='You are real user';
					$_SESSION['active']=$phone;
					header('location:../user_interface/');
				}else{
					$err="You try wrong password";
				}
			}
		}
	 ?>
	<?php require '../../connection/css.php'; ?>
	<style type="text/css">
		.center{
	position: fixed; /* or absolute */
  top: 50%;
  left: 50%;
  /* bring your own prefixes */
  transform: translate(-50%, -50%);

		}
	</style>
</head>
<body class="bg-dark">
	<div class="container-fulid center" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<h1 class="text-center"><img src="/Image/multi.png"></h1>
				<div>
					
				</div>
				<div>
					<br>
				</div>
				<form method="post" action="">
					<table class="table">
						
						<tr>
							<td><label for="number">Phone <span class="text-danger">*</span></label></td>
							<td><input id="number" required="" disabled="" class="form-control" type="number" value="<?php echo $_SESSION['phone']; ?>" name="phone" placeholder="013**-******"></td>
						</tr>
						<tr>
							<td><label for="password">Password</label><?php if(isset($err)){echo "<br><span class='text-danger'>". $err."</span>";} ?></td>
							<td><input id="password" class="form-control" type="password" name="password" placeholder="password"></td>
						</tr>
						
					</table>

					<input class="btn btn-primary" style="max-width: 200px; display: block; margin: 0 auto;" type="submit" name="submit" value="Login">
				</form>
				
			</div>
		</div>
	</div>
</body>
</html>