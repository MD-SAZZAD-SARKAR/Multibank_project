<!DOCTYPE html>
<html>
<head>
	<title>Deposit money for future</title>
	<link rel="stylesheet" type="text/css" href="/connection/bootstrap5.css">
	<style type="text/css">
		.custom1{
			display: none;
		}
		*{
			user-select: none;
		}
		
	</style>
</head>
<body>
	<?php require_once '../../connection/dbcon.php';?>
	<?php 




		
		session_start();
		$phone=$_SESSION['phone'];

		$row_count=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `deposit` WHERE `phone`='$phone'"));

		$row_query=mysqli_query($con,"SELECT * FROM `deposit` WHERE `phone`='$phone'");
		$total_d=0;
		if($row_count==0){
			
		}else{
			while($row=mysqli_fetch_assoc($row_query)){
				$total_d+=$row['money'];
			}
		}
		

		
			$money_d=$total_d;
			if ($money_d>0) {
				 $date = date("Y/m/d").date("h:i:sa");
				mysqli_query($con,"INSERT INTO `deposit`(`phone`, `money`) VALUES ('$phone','-$money_d')");
				mysqli_query($con,"INSERT INTO `$phone`(`tranjection_id`,`deposit`,`creadit`) VALUES ('$date', 'deposit','$money_d')");

			}
			header('location:deposit.php');
			
		

	?>
	<div id="relative" class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<div class="text-center text-light h3">MultiBank</div>
				<br>
				
			</div>
		</div>
	</div>
	
</body>
</html>