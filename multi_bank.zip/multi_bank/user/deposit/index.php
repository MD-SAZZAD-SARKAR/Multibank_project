<!DOCTYPE html>
<html>
<head>
	  <meta charset="UTF-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Deposit money for future</title>
	<link rel="stylesheet" type="text/css" href="/connection/bootstrap5.css">
</head>
<body class="bg-dark">
	<div id="relative" class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<div class="text-center text-light h3">MultiBank</div>
				<br>
				<div class="container-fulid m-2 text-light">
					Are You Want terms and condition?
					<hr>
					<p>
						Over the years, MultiBank has come a long way and now they are the leading mobile banking service providers in Bangladesh. As of May 2019, MultiBank has 3.1 crores, active users. They have added more user-demanded services like airtime top-up, bills payment, and train-movie ticket purchase, foreign remittance, etc. Multibank also offers ATM money withdrawal through mobile technology devices which is very convenient.
					</p>
					<div class="container-fulid row col-12 m-auto">
						<a class="btn btn-success col-6" href="deposit.php">Enter</a>
						<a class="btn btn-danger col-6" href="../user_interface/">Cancel</a>

					</div> 
				</div>
			</div>
		</div>
	</div>
</body>
</html>