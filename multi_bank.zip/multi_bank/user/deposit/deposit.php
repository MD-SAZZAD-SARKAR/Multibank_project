<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Deposit money for future</title>
	<link rel="stylesheet" type="text/css" href="/connection/bootstrap5.css">
	<style type="text/css">
		.custom1{
			display: none;
		}
		*{
			user-select: none;
		}
		
	</style>
</head>
<body class="bg-dark">
	<?php require_once '../../connection/dbcon.php';?>
	<?php 




		mysqli_query($con,"CREATE TABLE IF NOT EXISTS deposit(id int not null auto_increment, phone varchar(20), money int(100), primary key(id))");
		session_start();
		$phone=$_SESSION['phone'];

		$row_count=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `deposit` WHERE `phone`='$phone'"));

		$row_query=mysqli_query($con,"SELECT * FROM `deposit` WHERE `phone`='$phone'");
		$total_d=0;
		if($row_count==0){
			
		}else{
			while($row=mysqli_fetch_assoc($row_query)){
				$total_d+=$row['money'];
			}
		}
		$warning= "none";


		if(isset($_POST['submit'])){
			$money_d=$_POST['amount'];
			$money_main=$_SESSION['money'];
			if ($money_main>=$money_d) {
				 $date = date("Y/m/d").date("h:i:sa");
				mysqli_query($con,"INSERT INTO `deposit`(`phone`, `money`) VALUES ('$phone','$money_d')");
				mysqli_query($con,"INSERT INTO `$phone`(`tranjection_id`,`deposit`,`debit`) VALUES ('$date', 'deposit','$money_d')");
				$money_main=$money_main-$money_d;
				echo "<script>window.location.href='?'</script>";

			}
			else{
				$warning= "block";
			 
		}
			}
		

	?>
	<div id="relative" class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<div class="text-center text-light h3">MultiBank</div>
				<br>
				<div class=" container-fulid d-block btn btn-success">Your deposited amount: <?= $total_d; ?></div>
				<div class="container-fulid text-light">
					<div class="card bg-primary">
						<div class="card-header h5">
							How much money do you want to deposit?
						</div>
						<div class="card-body">
							<div class="btn-danger btn dosabled mb-1" style="display: <?=$warning;?>">You haven't enough money thank you try again
							</div>
							<div class=" w-100 mb-1">
								<form action="" method="post">
									<select name="amount" class="form-select mb-1">
										<option>Enter per month Amount</option>
										<option value="500">500</option>
										<option value="1000">1000</option>
										<option value="1500">1500</option>
										<option value="2000">2000</option>
										<option value="3000">3000</option>
										<option value="5000">5000</option>
										<option value="10000">10000</option>
										<option value="20000">20000</option>
									</select>

									<input class="btn btn-success w-100 mb-1" type="submit" name="submit" value="Submit">
									<br>
									<br>
									<a class="btn btn-success col-12" href="../user_interface/">Go Back</a>
									<a class="btn btn-danger col-12" href="cancel.php">calcel deposit</a>

								</form>
									
									
							</div> 
						</div>
					</div>


				</div>
				
				
			</div>
		</div>
	</div>
	
</body>
</html>