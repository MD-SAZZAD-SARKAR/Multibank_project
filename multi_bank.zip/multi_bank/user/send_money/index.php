<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank send money</title>
<style type="text/css">
	.row .col-6{
		padding: 0;
		margin: 0;
		font-size: 15px;

	}
	.row .col-6 .input{
		margin-bottom: 1px;
	}

</style>
	
	<?php session_start();
	if (!isset($_SESSION['enter'])) {
		echo "<script>window.location.href='../home/'</script>";
	}else if (!isset($_SESSION['phone'])) {
		echo "<script>window.location.href='../check_account/'</script>";
	} else if (!isset($_SESSION['login'])) {
		echo "<script>window.location.href='../login/'</script>";
	}else if (!isset($_SESSION['active'])) {
		echo "<script>window.location.href='../login/'</script>";
	}
	
		require_once("../../connection/dbcon.php");
		
	 ?>
	<?php require '../../connection/css.php'; ?>


	<?php 
		if (isset($_POST['submit'])) {
			$phone=$_POST['phone'];
			$money_inp=$_POST['money_inp'];
			$select_multibank_user=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `multi_user` WHERE `phone`='$phone'"));
			$fee=($money_inp/1)+5;
			if ($select_multibank_user==1) {
				if($phone==$_SESSION['phone']){
					$err= "It number not able to tranjection becuse it you";
				}else{
					$sender=$_SESSION['phone'];
					
					 $date = date("Y/m/d").date("h:i:sa");
					
					$insert_debit=mysqli_query($con,"INSERT INTO `$sender`(`tranjection_id`, `send_money`, `received_money`, `cash_out`, `cashin`, `debit`, `creadit`) VALUES ('$date','$phone','','','','$fee','')");

					$insert_creadit=mysqli_query($con,"INSERT INTO `$phone`(`tranjection_id`, `send_money`, `received_money`, `cash_out`, `cashin`, `debit`, `creadit`) VALUES ('$date','','$sender','','','','$money_inp')");
					echo "<script>window.location.href='../user_interface/'</script>";

				}
			}else{
				$err="Your account was wrong";
			}
		}

	 ?>
</head>
<body class="bg-dark">
	<div id="relative" class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div class="container">
			  <div class="row">
			    <div class="col-6">
			     <img style="width: 100px;" src="/Image/multi.png" title="logo">
			    </div>
			    <div class="col-6">
			    	<div class="h3 text-right text-light">Send Money</div>
			    </div>
			   
			    
			    
			  </div>
				<div class="row bg-light rounded">
				  	<div class="col-6">
				  		<form method="post" action="">
					  		<input required="" type="number" class="form-control" placeholder="Enter money receiver no" name="phone">
					  		<span class="bg-danger text-light rounded d-block mt-1 mb-1 "><?php if (isset($err)) {
					  			echo $err;
					  		} ?></span>
					  		<input required="" type="number" class="form-control" placeholder="Enter your ammount" id="money_inp" name="money_inp">
					  		<span class="bg-danger text-light rounded p-2 mt-1 mb-1 " id="err_m">You are try wrong amount?</span>
					  		<input class="btn btn-success d-block w-100" type="submit" name="submit">
				  		</form>
				  	</div>
				  	<div class="col-6 row">
				  		<div class="col-6">
				  			<div  class="text-end">Blance: <span id="bal"><?php echo $_SESSION['money']; ?></span></div>
				  			<div class="text-end">Avilable: <span id="avial"><?php echo $_SESSION['money']; ?></span></div>
				  		</div>
				  		<div class="col-6">
				  			<div class="text-end">Send: <span id="money_val"></span></div>
				  			<div class="text-end">Spend: 5</div>
				  			<div class="text-end">tax/vat: 0</div>

				  			<hr style="clor:red; margin: 0">
				  			<div class="text-end">Total: <span id="total">0</span></div>
				  		</div>

				  	</div>
					  	
				</div>
				<div>
					<div class="container-fulid">
						<div class="row">
							<hr class="m-0 p-0">
							<button id="home" class="btn col-6 p-2 rounded" style="background: linear-gradient(to left, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/home.png"> Home</button>

							<button id="inbox" class="btn col-6 p-2 rounded" style="background: linear-gradient(to right, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/email.png"> Inbox</button>
						</div>
					</div>
				</div>
			</div>
				
		</div>
	</div>
	<script type="text/javascript">
		var home=document.querySelector('#home');
		var inbox=document.querySelector('#inbox');
		home.style.background='linear-gradient(to left, #03C0CE, #565DDF)';
		inbox.style.background='linear-gradient(to right, #03C0CE, #565DDF)';
		inbox.onclick=function(){
			window.location.href='../inbox/';
		}
		home.onclick=function(){
			window.location.href='../user_interface/';
		}


		var money_inp=document.querySelector('#money_inp');
		var money_val=document.querySelector('#money_val');
		var bal=document.querySelector('#bal');
		var err_m=document.querySelector('#err_m');
		var total=document.querySelector('#total');
		var avial=document.querySelector('#avial');

		money_val.innerHTML=0;
		err_m.style.display='none';
		money_inp.oninput=function() {
			
			if ((money_inp.value/1)<=((bal.innerHTML/1)-5)) {
				money_val.innerHTML=money_inp.value;
				err_m.style.display='none';
				total.innerHTML=(money_inp.value/1)+5;
				avial.innerHTML=(bal.innerHTML/1)-(total.innerHTML/1);
				document.querySelector('input[type=submit]').disabled='';
			}else{
				err_m.style.display='block';
				document.querySelector('input[type=submit]').disabled='true';
			}
			
		}
		


	
	</script>
</body>
</html>