<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank Registration page</title>
	<?php session_start();
		require_once("../../connection/dbcon.php");
		if (!isset($_SESSION['enter'])) {
			echo "<script> window.location.href='../home/'</script>";
		}else if (!isset($_SESSION['phone'])) {
			echo "<script> window.location.href='../check_account/'</script>";
		}else if (isset($_SESSION['phone'])) {
			$phone=$_SESSION['phone'];
		}

		if (isset($_POST['submit'])) {
			$name=$_POST['name'];
			$father=$_POST['father'];
			$mother=$_POST['mother'];
			$roll=$_POST['roll'];
			$reg=$_POST['reg'];
			$nid=$_POST['nid'];

			if (!empty($roll) or !empty($nid)) {
				$count_table=$con->query("SHOW TABLES LIKE '%$phone%'");
				$count_table=mysqli_num_rows($count_table);
				if ($count_table!==1) {
					$submit=mysqli_query($con,"INSERT INTO `multi_user`(`name`, `nid`, `father`, `mother`, `phone`, `roll`, `registration`,`password`) VALUES ('$name', '$nid', '$father', '$mother', '$phone', '$roll', '$reg', '' )");
					if ($submit) {
						$create_user_tranjection=mysqli_query($con, "CREATE TABLE IF NOT EXISTS `$phone`(id int(11) NOT NULL AUTO_INCREMENT, tranjection_id varchar(100), deposit varchar(100), send_money varchar(15), received_money varchar(15), cash_out varchar(20), cashin varchar(20), debit int(15), creadit int(15), PRIMARY key(id))");
							if ($create_user_tranjection) {
								$_SESSION['reg_pass_set']=$phone;
								header('location:../password_set/');
							}
					}
				}else{
					echo "<script> window.location.href='../check_account/'</script>";
				}

			}
			
		}

	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<h1 class="text-center"><img src="/Image/multi.png"></h1>
				<div>
					
				</div>
				<div>
					<br>
				</div>
				<form method="post" action="">
					<table class="table">
						<tr>
							<th><label for="name">Name <span class="text-danger">*</span></label></th>
							<th><input class="form-control " type="text" name="name" required="" required="" id="name" placeholder="MD. ****"></th>
						</tr>
						<tr>
							<td><label for="number">Phone <span class="text-danger">*</span></label></td>
							<td><input id="number" required="" disabled="" class="form-control" type="number" value="<?php echo $phone; ?>" name="phone" required="" placeholder="013**-******"></td>
						</tr>
						<tr>
							<td><label for="father">Father <span class="text-danger">*</span></label></td>
							<td><input id="father" class="form-control" type="text" name="father" required="" placeholder="sekan*** sarkar"></td>
						</tr>
						<tr>
							<td><label for="mother">Mother <span class="text-danger">*</span></label></td>
							<td><input id="mother" class="form-control" type="text" name="mother" required="" placeholder="umme**** k***"></td>
						</tr>
						<tr>
							<td><label for="roll">Roll <span class="text-danger">*</span></label></td>
							<td><input id="roll" class="form-control" type="number" name="roll" required="" placeholder="***773"></td>
						</tr>
						<tr>
							<td><label for="reg">Registration <span class="text-danger">*</span></label></td>
							<td><input required="" id="reg" class="form-control" type="number" name="reg" placeholder="15020****"></td>
						</tr>
						<tr>
							<td><label for="nid">Nid <span class="text-danger">*</span></label></td>
							<td><input required="" pattern=".{10,}" id="nid" class="form-control" type="number" name="nid" placeholder="nid"></td>
						</tr>
						
					</table>

					<input class="btn btn-primary" style="max-width: 200px; display: block; margin: 0 auto;" type="submit" name="submit" value="Registration">
				</form>
				
			</div>
		</div>
	</div>
</body>
</html>