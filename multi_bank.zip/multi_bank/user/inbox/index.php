<!DOCTYPE html>
<html>
<head>
	<title>Multi bank user interface</title>

	<style type="text/css">
		#relative{
			position: relative;
		}
		#menu_full{
			background: blue;
			position: absolute;
			top: 0;
			right: 0;
			width: 0;
			border-radius: 5px;
			width: 70%;
			display: none;
			padding: 15px;
			

		}
		#menu_full hr{
			color: white;
		}
		#menu_full p span{
			float: right;
		}
		#menu_full p #close{
			font-size: 30px;
			color: red;
			font-weight: bold;
			margin-top: -10px;
		}
		
		#satar{
			margin: 0;
			padding: 0;
		}
		#back{
			margin: 0;
			padding: 0;
		}
		#back div:hover{
			background: #eee;
		}
		#back div a{
			text-decoration: none;
			font-size: 15px;
		}
		#back div a:hover{
			font-size: 15px;
			background: #eee;
			cursor: pointer;
		}
		#close:hover{
			cursor: pointer;
		}
		img:hover{
			cursor:pointer;
		}
	</style>
	<?php session_start();
	if (!isset($_SESSION['enter'])) {
		echo "<script>window.location.href='../home/'</script>";
	}else if (!isset($_SESSION['phone'])) {
		echo "<script>window.location.href='../check_account/'</script>";
	} else if (!isset($_SESSION['login'])) {
		echo "<script>window.location.href='../login/'</script>";
	}else if (!isset($_SESSION['active'])) {
		echo "<script>window.location.href='../login/'</script>";
	}
	
		require_once("../../connection/dbcon.php");
		
	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div  class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div id="relative" class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div class="container">
			  <div class="row">
			    <div class="col-6">
			     <img style="width: 100px;" src="/Image/multi.png" title="logo">
			    </div>
			   
			    <div  class="col-6 mb-2 text-end text-light mt-3">
			     <img id="menu" style="width: 20px;" src="/Image/menu-circles.png">
			    <?php require_once "../side/index.php";?>
			    </div>
			    
			  </div>
			  <div class="row bg-light rounded">
			  	<div class="text-center" id="satar">
			  		<div>
			  			<button id="money" disabled class="disabled btn btn-secondary w-100">
			  				<?php 
			  					$phone=$_SESSION['phone'];
			  					$debit=0;
			  					$creadit=0;
			  					$slect_money=mysqli_query($con,"SELECT * FROM `$phone`");
			  					while ($row=mysqli_fetch_assoc($slect_money)) {
			  						$debit+=$row['debit'];
			  						$creadit+=$row['creadit'];
			  					}

			  					$money=($creadit/1)-($debit/1);
			  					$_SESSION['money']=$money;
			  					echo $money;
			  				 ?>
			  				<span>৳</span></button>
			  			<button id="money_btn" class="btn btn-secondary w-100">Show money</button>

			  		</div>
			  	</div>
				  	<div class="container-fulid row m-0 p-0 col-12">
					  <div class="col-6 p-0">
					  	<button id="inboxb" class="btn btn-success w-100">Inbox</button>
					  </div>
					  <div class="col-6 p-0">
					  	<button id="historyb" class="btn btn-primary w-100">History</button>
					  </div>
					  <div  id="inboxbc" class="col-12" style="overflow: scroll; max-height: 400px;">
					  	<?php require_once('massage.php');?>
					  </div>
					  <div id="historybc" style="overflow: scroll; max-height: 400px;">
					  	<?php require_once('history.php');?>
					  </div>


					  


				  	</div>
				</div>
				<div>
					<div class="container-fulid">
						<div class="row">
							<hr class="m-0 p-0">
							<button id="home" class="btn col-6 rounded" style="background: linear-gradient(to left, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/home.png"> Home</button>

							<button id="inbox" class="btn col-6 rounded" style="background: linear-gradient(to right, #03C0CE, #565DDF);"><img class="" style="width:20px;" src="/Image/email.png"> Inbox</button>
						</div>
					</div>
				</div>
			</div>
				
		</div>
	</div>
	<script type="text/javascript">
		var home=document.querySelector('#home');
		var inbox=document.querySelector('#inbox');
		home.style.background='linear-gradient(to right, #03C0CE, #565DDF)';
		inbox.style.background='white';
		home.onclick=function(){
			window.location.href='../user_interface/';
		}


		var menu=document.querySelector('#menu');
		var menu_full=document.querySelector('#menu_full');
		var close=document.querySelector('#close');
		close.style.display='none';
		menu.onclick=function () {
			menu_full.style.display='block';
			close.style.display='block';

		}
		close.onclick=function () {
			menu_full.style.display='none';
			this.style.display='none';
		}


		var money=document.querySelector('#money');
		var money_btn=document.querySelector('#money_btn');
		money.style.display='none';

		money_btn.onclick=function(){
			money.style.display='block';
			money_btn.style.display='none';
			setTimeout(function(){
				money.style.display='none';
				money_btn.style.display='block';
			},5000);
		}



		var inboxb=document.querySelector('#inboxb');
		var inboxbc=document.querySelector('#inboxbc');
		var historyb=document.querySelector('#historyb');
		var historybc=document.querySelector('#historybc');

		historybc.style.display='none';
		historyb.onclick=function(){
			historybc.style.display='block';
			inboxbc.style.display='none';	
		}

		inboxb.onclick=function(){
			historybc.style.display='none';
			inboxbc.style.display='block';	
		}

	</script>
</body>
</html>