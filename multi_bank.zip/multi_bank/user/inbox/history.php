<div class="row">
	<div class="col-12">
		
<h3 class="text-center">Tranjectio History</h3>

<table class="table bg-secondary ">
	<tr>
		<th>T Name</th>
		<th>Money</th>
		<th>T id</th>
	</tr>
			<?php 
	$phone=$_SESSION['phone'];
	$count_row=0;
	$row=mysqli_query($con, "SELECT * FROM `$phone` ORDER BY `id` DESC");
	while ($roww=mysqli_fetch_assoc($row)) {
		$count_row+=1;
		if ($count_row==31) {
			break;
		}
	
 ?>
	<tr>

		<td>
			<?php
		  if($roww['send_money']==''){ 	
			}else{
				echo 'Send '.$roww['send_money'];
			} 

		?>
		<?php
		  if($roww['received_money']==''){
		  	}else{
		  		echo 'Receved '.$roww['received_money'];
		
		  	}

		?>
		<?php
		  if($roww['cash_out']==''){
		  	}else{
		  		echo 'Cash Out '.$roww['cash_out'];
		  	}
		?>
		<?php
		  if($roww['cashin']==''){
		  	}else{
		  		echo 'Cash In '.$roww['cashin'];
		  	}

		?>
		<?php
		  if($roww['deposit']==''){
		  	}else{
		  		echo 'Deposit '.$roww['cashin'];
		  	}

		?>

		</td>
		<td>
	<?php
		  if($roww['debit']>0){
		  	echo'-'. $roww['debit'];
		} 

		?>

	<?php
		  if($roww['creadit']>0){
		  	echo '+'.$roww['creadit'];
		} 

	?>
		</td>
		<td>
	<?php
		  if($roww['tranjection_id']!=='NAN'){
		  	echo $roww['tranjection_id'];
		} 

	?>
		</td>

	</tr>
	<?php } ?>
	</table>	




	</div>
</div>