

	<div class="row" >
		<?php 
			$phone=$_SESSION['phone'];
			$count_roww=0;
			$select_messege=mysqli_query($con, "SELECT * FROM `massage` ORDER BY `id` DESC");
			while ($messege_row=mysqli_fetch_assoc($select_messege)) {
				$count_roww+=1;
				if ($count_roww==21) {
					break;
				}
			
		 ?>
		<div class="col-4">
			<img src="/image/<?= $messege_row['img'];?>" class='w-100' style='border-radius: 50%;'>
		</div>
		<div class="col-8">
			<div style="border: 1px solid gray">
				<div class="card-header">
					<?= $messege_row['name'];?>
				</div>
				<div class="card-body">
					<?= $messege_row['content'];?>
					<br>
					(<?= $messege_row['date'];?>)

				</div>
			</div>
		</div>
	<?php } ?>
	</div>
