<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank home page</title>
	<?php session_start();
		if (isset($_POST['submit'])) {
			$_SESSION['enter']='first';
		}
		if (isset($_SESSION['enter'])) {
			header('location:../check_account/');
		}

	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div class="container-fulid center" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<h1 class="text-center"><img src="/Image/multi.png"></h1>
				
				<form method="post" action="">
					<input class="btn btn-primary" style="max-width: 200px; display: block; margin: 0 auto;" type="submit" name="submit" value="Login/ Registration">
				</form>
				<p class="text-center">You can create account by nid or student id card.</p>
			</div>
		</div>
	</div>
</body>
</html>