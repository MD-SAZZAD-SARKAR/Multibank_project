<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
 	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multi bank home page</title>
	<?php session_start();
	if (!isset($_SESSION['enter'])) {
		echo "<script>window.location.href='../home/'</script>";
	}else if(!isset($_SESSION['phone'])) {
		echo "<script>window.location.href='../check_account/'</script>";
	}else if(!isset($_SESSION['reg_pass_set'])) {
		echo "<script>window.location.href='../registration/'</script>";
	}
		require_once("../../connection/dbcon.php");
		if(isset($_POST['submit'])){
			$password=$_POST['password'];
			$cpassword=$_POST['cpassword'];
			$phone=$_SESSION['phone'];
			if($password==$cpassword){
				$password=md5($password);
				$update_password=mysqli_query($con,"UPDATE `multi_user` SET `password`='$password' WHERE `phone`='$phone'");
				echo "<script>window.location.href='../login/'</script>";
			}
			
		}
		

	 ?>
	<?php require '../../connection/css.php'; ?>
</head>
<body class="bg-dark">
	<div class="container-fulid" style="max-width: 400px; display: block; margin: 0 auto;">
		<div class="p-2 rounded" style="background: linear-gradient(to top right, #03C0CE, #565DDF); ">
			<div>
				<h1 class="text-center"><img src="/Image/multi.png"></h1>
				<div>
					
				</div>
				<div>
					<br>
				</div>
				<form method="post" action="">
					<table class="table">
						<tr>
							<td><label for="phone">Phone</label></td>
							<td><input disabled value="<?php echo $_SESSION['phone'];?>" class="form-control" type="text" id="phone" name="phone"></td>
							
						</tr>
						<tr>
							<td><label for="password">Password</label></td>
							<td><input class="form-control" type="number" id="password" name="password"></td>
							
						</tr>
						<tr>
							<td><label for="cpassword">Confirm Password</label></td>
							<td><input class="form-control" type="number" id="cpassword" name="cpassword"></td>
						</tr>
					</table>
					<input class="btn btn-primary" style="max-width: 200px; display: block; margin: 0 auto;" type="submit" name="submit" value="Submit">
				</form>
				<p class="text-center">You can create account by nid or student id card.</p>
			</div>
		</div>
	</div>
</body>
</html>