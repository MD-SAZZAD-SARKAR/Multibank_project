<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<meta charset="UTF-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="/connection/bootstrap5.css">
	<style type="text/css">
		.center{
	position: fixed; /* or absolute */
  top: 50%;
  left: 50%;
  /* bring your own prefixes */
  transform: translate(-50%, -50%);

		}
	</style>
</head>
<body class="bg-dark">
	<div class="center">
		<div  class="rounded" style="background: linear-gradient(to top right, yellow, gray, purple, #565DDF);">
			<div class="card bg-primary">
				<div class="card-header">
					<div class="text-light h3 text-center">
						Welcome to Login Page?
						<br>
						For control
					</div>
				</div>
				<div class="card-body bg-dark text-light">
					<form action="" method="post">
					    <div class="row mb-2">
					    	<div class="col-sm-4">
					    		<label for="inputEmail3" class="col-form-label">Phone</label>
					    	</div>
					    	<div class="col-sm-8">
					    		<input placeholder="phone" type="text" required="" class="form-control" id="inputEmail3">
					    	</div>
					    </div>
					    
					    <div class="row mb-2">
					    	<div class="col-sm-4">
					    		<label for="inputPassword3" class="col-form-label">Password</label>
					    	</div>
					    	<div class="col-sm-8">
					    		 <input placeholder="password" required="" type="password" class="form-control" id="inputPassword3">
					    	</div>
					    </div>
					     <button type="submit" class="btn btn-primary w-100">Sign in</button>
					 </form>
					 <br>
					  <p class="text-center text-bolder">Haven't Account <a class="text" href="../registration/">Regestration now?</a></p>
					  </div>
					 
					
				</div>
			</div>
			
			
		</div>
	</div>
</body>
</html>