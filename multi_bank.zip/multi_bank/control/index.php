<!DOCTYPE html>
<html>
<head>
	<title>Please control web page</title>
</head>
<body>
	<?php header('location:login/'); ?>
</body>
</html>