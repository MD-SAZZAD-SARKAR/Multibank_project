<!DOCTYPE html>
<html>
<head>
  <title>templaete</title>
 <link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.css"
  rel="stylesheet"
/>
<style type="text/css">
  body {
  background-color: #fbfbfb;
}
@media (min-width: 991.98px) {
  main {
    padding-left: 240px;
  }
}

/* Sidebar */
.sidebar {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  padding: 58px 0 0; /* Height of navbar */
  box-shadow: 0 2px 5px 0 rgb(0 0 0 / 5%), 0 2px 10px 0 rgb(0 0 0 / 5%);
  width: 240px;
  z-index: 600;
}

@media (max-width: 991.98px) {
  .sidebar {
    width: 100%;
  }
}
.sidebar .active {
  border-radius: 5px;
  box-shadow: 0 2px 5px 0 rgb(0 0 0 / 16%), 0 2px 10px 0 rgb(0 0 0 / 12%);
}

.sidebar-sticky {
  position: relative;
  top: 0;
  height: calc(100vh - 48px);
  padding-top: 0.5rem;
  overflow-x: hidden;
  overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */
}
</style>
</head>
<body>
  <!--Main Navigation-->
<!--Main Navigation-->
<header>
  <!-- Sidebar -->
  <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-dark">
    <div class="position-sticky">
      <div class="list-group list-group-flush mx-3 mt-4">
        
        
        
        <a style="border-bottom: 1px solid white;" href="#dashbord" class="list-group-item bg-dark text-light list-group-item-action py-2 ripple"
          ><i class="fas fa-tachometer fa-fw me-3" ></i><span>Dashbord</span></a
        ><a style="border-bottom: 1px solid white;" href="#moneytransfer" class="list-group-item bg-dark text-light list-group-item-action py-2 ripple"
          ><i class="fas fa-paper-plane fa-fw me-3" ></i><span>Send</span></a
        ><a style="border-bottom: 1px solid white;" href="#inbox" class="list-group-item bg-dark text-light list-group-item-action py-2 ripple"
          ><i class="fas fa-inbox fa-fw me-3" ></i><span>Inbox</span></a
        >

      </div>
    </div>
  </nav>
  <!-- Sidebar -->

  <!-- Navbar -->
  <nav id="main-navbar" class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
    <!-- Container wrapper -->
    <div class="container-fluid">
      <!-- Toggle button -->
      <button
        class="navbar-toggler"
        type="button"
        data-mdb-toggle="collapse"
        data-mdb-target="#sidebarMenu"
        aria-controls="sidebarMenu"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <i class="fas fa-bars"></i>
      </button>

      <!-- Brand -->
      <a class="navbar-brand" href="#">
        <img
          src="/image/multi.png"
          height="25"
          alt="MDB Logo"
          loading="lazy"
        />
      </a>
      <!-- Search form -->
      <div class="d-none d-md-flex input-group w-auto my-auto">
        <h1 class="text-light">Welcome to Multi bank Management System</h1>
      </div>

      <!-- Right links -->
      
    </div>
    <!-- Container wrapper -->
  </nav>
  <!-- Navbar -->
</header>
<!--Main Navigation-->

<!--Main layout-->
<main style="margin-top: 58px;">
  <div class="container pt-4">
    <div class="card" id="dashbord">
      <div class="card-header text-dark h3">
       <i class="fas fa-tachometer fa-fw me-1" ></i> Your DashBord
      </div>
      <div class="card-body">
        <div class="row">

          <div class="col-sm-4 col-md-3 col-xl-2">
            <div class="card">
              <div class="card-header bg-primary">
                <h2 class="text-center text-light h5">Total Messege</h2>
              </div>
              <div class="card-body text-center">
                50
              </div>
            </div>
          </div>
          <div class="col-sm-4 col-md-3 col-xl-2">
            <div class="card">
              <div class="card-header bg-primary">
                <h2 class="text-center text-light h5">Total Messege</h2>
              </div>
              <div class="card-body text-center">
                50
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    <!-- next step -->
    <div class="card" id="moneytransfer">
      <div class="card-header text-dark h3">
       <i class="fas fa-table fa-fw me-1" ></i> Money Send
      </div>
      <div class="card-body">
       <form>
         <input placeholder="Enter receiver Account No." class="form-control mb-2" type="text" id="phone_money" name="">
         <input placeholder="Enter Amount" class="form-control mb-2" type="text" id="amount_money" name="">
          <input placeholder="Enter password" class="form-control mb-2" type="text" id="password" name="">

         <button class="btn btn-success w-100"><i class="fas fa-paper-plane me-2"></i>Send</button>
       </form>
        <div class="mt-4">
          recent tranjection..............
        </div>
      </div>
      
    </div>
    <!-- next Step -->

    <div class="card" id="inbox">
      <div class="card-header text-dark h3">
       <i class="fas fa-inbox fa-fw me-1" ></i> Inbox
      </div>
      <div class="card-body">
       <form>
         
        
        <textarea class="form-control mb-2" placeholder="Enter your messege or offer" id="inbox_type" rows="6">
          
        </textarea>
        <script type="text/javascript">
          document.querySelector('#inbox_type').value='';
        </script>

         <button class="btn btn-success w-100"><i class="fas fa-paper-plane me-2"></i>Send</button>
       </form>
        <div class="mt-4">
          recent inbox..............
        </div>
      </div>
      
    </div>
    <!-- next step -->
    <div>
      <h1 class="text-center">Allright Reserved &copy; <?php echo $_SERVER['SERVER_NAME']; ?> 2022</h1>
    </div>
  </div>
</main>
<!--Main layout-->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.js"
></script>
</body>
</html>